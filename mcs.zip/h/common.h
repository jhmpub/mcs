#ifndef COMMON_H
#define COMMON_H

#define AUDIO_EFFECT_CONTROL_NOTIFICATION_PORT (short) 2002
#define AUDIO_CONTROL_NOTIFICATION_PORT (short) 2001
#define AUDIO_CONTROL_REQUEST_PORT (short) 2000
#define AUDIO_CONTROL_SERVER_HOSTNAME "jimson"
#define AUDIO_CONTROL_UNIFIED_HOSTNAME "localhost"

#define DEFAULT_COM_PORT 5

#define UNINITIALIZED 0
#define UNDEFINED -1
#define EXIT -2

#define SZ_UNINITIALIZED "uninitialized"
#define SZ_UNDEFINED "undefined"
#define SZ_EXIT "exit"

// initializing to the maximum volume levels insures sufficient "down"
// volume commands will be issued during ampInit to reach volume floors
static int masterVolume=MASTER_VOLUME_MAX;
static int centerVolume=EFFECT_VOLUME_MAX;
static int subwooferVolume=EFFECT_VOLUME_MAX;
static int surroundRightVolume=EFFECT_VOLUME_MAX;
static int surroundLeftVolume=EFFECT_VOLUME_MAX;
static int inputSource=VIDEO_AUX;
static int station=FM1;
static int currentEffectSpeaker=0;
static int powerState, muteState, poweringOff;
static int registrationCount, surroundProfile;
static int channelA_Relay, channelA_Switch, rearSpeakerSwitch;
static int rearSpeakerState, frontSpeakerState, denSpeakerState;
static int subwooferState, LFE_State;
static int undefined = UNDEFINED;

static struct serverState {
    int rearSpeakerState; 
    int frontSpeakerState; 
    int denSpeakerState;
    int inputSource;
} serverState, *preserved=NULL;        

// The default mode for stereo sources is DSP_EFFECT_OFF which means
// the center, rear and subwoofer speakers are disabled.
// DSP_EFFECT_ON is used to upmix stereo and decode surround sound
// using the desired program
//
// HD sources are all hardcoded to use Dolby Normal decoding with DSP_EFFECT_ON.
// The Dolby Enhanced sub-mode does not seemt to utilize the center channel 
// very well whenever the audio source is stereo.
//
// DSP is toggled on and off by pressing the "EFFECT" button on the 
// yamaha remote.
//
// All dsp mode settings are input source specific and normally retained in the
// standby power state.  Nonetheless, all input source DSP settings are reset
// during initialization to insure a known state.

static struct dsp { // digital sound processor
    int inputSource;
    const int program;
    int state;            // DSP_EFFECT_ON or DSP_EFFECT_OFF
    const int toggle;     // whether state can change after init
} dsp[] = {

    {DVD,                // DVD always uses Dolby Normal
     DSP_DOLBY_NORMAL,
     DSP_EFFECT_ON,
     DSP_EFFECT_TOGGLE_DISABLE},
     
    {FM,                 // TUNER always has the DSP Effect Off
     DSP_DOLBY_NORMAL,
     DSP_EFFECT_OFF,
     DSP_EFFECT_TOGGLE_DISABLE},
     
    {GEORGIA,            // CD uses DSP_OFF for stereo and Dolby Normal when the surround speakers enabled
     DSP_DOLBY_NORMAL,
     DSP_EFFECT_OFF,
     DSP_EFFECT_TOGGLE_ENABLE},
     
    {JIMSON,             // CBL/SAT uses DSP_OFF for stereo and Dolby Normal when the surround speakers enabled
     DSP_DOLBY_NORMAL,
     DSP_EFFECT_OFF,
     DSP_EFFECT_TOGGLE_ENABLE},
     
    {LVR_MM,             // CD-R always uses Dolby Normal
     DSP_DOLBY_NORMAL,
     DSP_EFFECT_ON,
     DSP_EFFECT_TOGGLE_DISABLE},
     
    {DEN_MM,             // V-AUX always uses Dolby Normal
     DSP_DOLBY_NORMAL,
     DSP_EFFECT_ON,
     DSP_EFFECT_TOGGLE_DISABLE},
     
    {TV,                 // D-TV/LD always uses Dolby Normal
     DSP_DOLBY_NORMAL,
     DSP_EFFECT_ON,
     DSP_EFFECT_TOGGLE_DISABLE},
     
    {VIDEO_AUX,          // V-AUX is an unconnected source that always uses Dolby Normal for initialization
     DSP_DOLBY_NORMAL,
     DSP_EFFECT_ON,
     DSP_EFFECT_TOGGLE_DISABLE},
};

static struct irCmd {
    int id;
    char * sz;
    int * state;
    int size;   // number of bytes in the codes array
    unsigned char const * codes;
} irCmd[] = { 

    // yamaha irCmds
    {POWER_ON,
     SZ_POWER_ON,
     &powerState,
     sizeof(irPowerOn),
     irPowerOn},
     
    {POWER_OFF,
     SZ_POWER_OFF,
     &powerState,
     sizeof(irPowerOff),
     irPowerOff},
     
    {GEORGIA,
     SZ_GEORGIA,
     &inputSource,
     sizeof(irCD),
     irCD},
     
    {JIMSON,
     SZ_JIMSON,
     &inputSource,
     sizeof(irCblSat),
     irCblSat},
     
    {MACMINI,
     SZ_MACMINI,
     &inputSource,
     sizeof(irCDR),
     irCDR},
     
    {LVR_MM,
     SZ_LVR_MM,
     &inputSource,
     sizeof(irCDR),
     irCDR},
     
    {DEN_MM,
     SZ_DEN_MM,
     &inputSource,
     sizeof(irVideoAux),
     irVideoAux},
     
    {FM,
     SZ_FM,
     &inputSource,
     sizeof(irFm),
     irFm},
     
    {TV,
     SZ_TV,
     &inputSource,
     sizeof(irTv),
     irTv},
     
    {DVD,
     SZ_DVD,
     &inputSource,
     sizeof(irDvd),
     irDvd},
     
    {VIDEO_AUX,
     SZ_VIDEO_AUX,
     &inputSource,
     sizeof(irVideoAux),
     irVideoAux},
     
    {FM1,
     SZ_FM1,
     &station,
     sizeof(irFm1),
     irFm1},
     
    {FM2,
     SZ_FM2,
     &station,
     sizeof(irFm2),
     irFm2},
     
    {FM3,
     SZ_FM3,
     &station,
     sizeof(irFm3),
     irFm3},
     
    {FM4,
     SZ_FM4,
     &station,
     sizeof(irFm4),
     irFm4},
     
    {FM5,
     SZ_FM5,
     &station,
     sizeof(irFm5),
     irFm5},
     
    {FM6,
     SZ_FM6,
     &station,
     sizeof(irFm6),
     irFm6},
     
    {FM7,
     SZ_FM7,
     &station,
     sizeof(irFm7),
     irFm7},
     
    {FM8,
     SZ_FM8,
     &station,
     sizeof(irFm8),
     irFm8},
     
    {MUTE_ON,
     SZ_MUTE_ON,
     &muteState,
     sizeof(irMuteToggle),
     irMuteToggle},
     
    {MUTE_OFF,
     SZ_MUTE_OFF,
     &muteState,
     sizeof(irMuteToggle),
     irMuteToggle},
     
    {MUTE_TOGGLE,
     SZ_MUTE_TOGGLE,
     &muteState,
     sizeof(irMuteToggle),
     irMuteToggle},
     
    {REGISTER,
     SZ_REGISTER,
     &undefined,
     0,
     NULL},
     
    {DEREGISTER,
     SZ_DEREGISTER,
     &undefined,
     0,
     NULL},
     
    {MASTER_VOLUME,
     SZ_MASTER_VOLUME,
     &masterVolume,
     0,
     NULL},
     
    {MASTER_VOLUME_UP,
     SZ_MASTER_VOLUME_UP,
     &masterVolume,
     sizeof(irMasterVolumeUp),
     irMasterVolumeUp},
     
    {MASTER_VOLUME_DOWN,
     SZ_MASTER_VOLUME_DOWN,
     &masterVolume,
     sizeof(irMasterVolumeDn),
     irMasterVolumeDn},
     
    {CENTER_VOLUME,
     SZ_CENTER_VOLUME,
     &centerVolume,
     0,
     NULL},
     
    {CENTER_VOLUME_UP,
     SZ_CENTER_VOLUME_UP,
     &centerVolume,
     sizeof(irMenuRight),
     irMenuRight},
     
    {CENTER_VOLUME_DOWN,
     SZ_CENTER_VOLUME_DOWN,
     &centerVolume,
     sizeof(irMenuLeft),
     irMenuLeft},
     
    {SURROUND_VOLUME,
     SZ_SURROUND_VOLUME,
     &surroundRightVolume,
     0,
     NULL},
     
    {SURROUND_RIGHT_VOLUME,
     SZ_SURROUND_RIGHT_VOLUME,
     &surroundRightVolume,
     0,
     NULL},
     
    {SURROUND_RIGHT_VOLUME_UP,
     SZ_SURROUND_RIGHT_VOLUME_UP,
     &surroundRightVolume,
     sizeof(irMenuRight),
     irMenuRight},
     
    {SURROUND_RIGHT_VOLUME_DOWN,
     SZ_SURROUND_RIGHT_VOLUME_DOWN,
     &surroundRightVolume,
     sizeof(irMenuLeft),
     irMenuLeft},
     
    {SURROUND_LEFT_VOLUME,
     SZ_SURROUND_LEFT_VOLUME,
     &surroundLeftVolume,
     0,
     NULL},
     
    {SURROUND_LEFT_VOLUME_UP,
     SZ_SURROUND_LEFT_VOLUME_UP,
     &surroundLeftVolume,
     sizeof(irMenuRight),
     irMenuRight},
     
    {SURROUND_LEFT_VOLUME_DOWN,
     SZ_SURROUND_LEFT_VOLUME_DOWN,
     &surroundLeftVolume,
     sizeof(irMenuLeft),
     irMenuLeft},
     
    {SUBWOOFER_VOLUME,
     SZ_SUBWOOFER_VOLUME,
     &subwooferVolume,
     0,
     NULL},
     
    {SUBWOOFER_VOLUME_UP,
     SZ_SUBWOOFER_VOLUME_UP,
     &subwooferVolume,
     sizeof(irMenuRight),
     irMenuRight},
     
    {SUBWOOFER_VOLUME_DOWN,
     SZ_SUBWOOFER_VOLUME_DOWN,
     &subwooferVolume,
     sizeof(irMenuLeft),
     irMenuLeft},
     
    {SURROUND_MIN,
     SZ_SURROUND_MIN,
     &surroundProfile,
     0,
     NULL},
     
    {SURROUND_STD,
     SZ_SURROUND_STD,
     &surroundProfile,
     0,
     NULL},
     
    {SURROUND_MAX,
     SZ_SURROUND_MAX,
     &surroundProfile,
     0,
     NULL},
     
    {MENU_EFFECT_SPEAKER_LEVEL,
     SZ_MENU_EFFECT_SPEAKER_LEVEL,
     &undefined,
     sizeof(irMenuEffectSpeakerLevel),
     irMenuEffectSpeakerLevel},
     
    {MENU_SETTINGS,
     SZ_MENU_SETTINGS,
     &undefined,
     sizeof(irMenuSet),
     irMenuSet},
     
    {MENU_UP,
     SZ_MENU_UP,
     &undefined,
     sizeof(irMenuUp),
     irMenuUp},
     
    {MENU_DOWN,
     SZ_MENU_DOWN,
     &undefined,
     sizeof(irMenuDown),
     irMenuDown},
     
    {MENU_LEFT,
     SZ_MENU_LEFT,
     &undefined,
     sizeof(irMenuLeft),
     irMenuLeft},
     
    {MENU_RIGHT,
     SZ_MENU_RIGHT,
     &undefined,
     sizeof(irMenuRight),
     irMenuRight},
     
    {DSP_EFFECT_ON,
     SZ_DSP_EFFECT_ON,
     &undefined,
     sizeof(irDspEffectToggle),
     irDspEffectToggle},
     
    {DSP_EFFECT_OFF,
     SZ_DSP_EFFECT_OFF,
     &undefined,
     sizeof(irDspEffectToggle),
     irDspEffectToggle},
     
    {DSP_EFFECT_TOGGLE,
     SZ_DSP_EFFECT_TOGGLE,
     &undefined,
     sizeof(irDspEffectToggle),
     irDspEffectToggle},
     
    {DSP_DOLBY_NORMAL,
     SZ_DSP_DOLBY_NORMAL,
     &undefined,
     sizeof(irDspDolbyNormal),
     irDspDolbyNormal},
     
     // xantech irCmds
    {CHANNEL_A_TO_FRONT_SPEAKERS,
     SZ_CHANNEL_A_TO_FRONT_SPEAKERS,
     &channelA_Switch,
     sizeof(irOff0),
     irOff0},
     
    {CHANNEL_A_TO_AB_SWITCH,
     SZ_CHANNEL_A_TO_AB_SWITCH,
     &channelA_Switch,
     sizeof(irOn0),
     irOn0},
     
    {REAR_SPEAKERS_FROM_AB_SWITCH,
     SZ_REAR_SPEAKERS_FROM_AB_SWITCH,
     &rearSpeakerSwitch,
     sizeof(irOff1),
     irOff1},
     
    {REAR_SPEAKERS_FROM_REAR_CHANNEL,
     SZ_REAR_SPEAKERS_FROM_REAR_CHANNEL,
     &rearSpeakerSwitch,
     sizeof(irOn1),
     irOn1},
     
    {CHANNEL_A_RELAY_OFF,
     SZ_CHANNEL_A_RELAY_OFF,
     &channelA_Relay,
     sizeof(irOff2),
     irOff2},
     
    {CHANNEL_A_RELAY_ON,
     SZ_CHANNEL_A_RELAY_ON,
     &channelA_Relay,
     sizeof(irOn2),
     irOn2},
     
    {CHANNEL_B_SPEAKERS_OFF,
     SZ_CHANNEL_B_SPEAKERS_OFF,
     &denSpeakerState,
     sizeof(irOff3),
     irOff3},
     
    {CHANNEL_B_SPEAKERS_ON,
     SZ_CHANNEL_B_SPEAKERS_ON,
     &denSpeakerState,
     sizeof(irOn3),
     irOn3},
     
    {SUBWOOFER_OFF,
     SZ_SUBWOOFER_OFF,
     &subwooferState,
     sizeof(irOff4),
     irOff4},
     
    {SUBWOOFER_ON,
     SZ_SUBWOOFER_ON,
     &subwooferState,
     sizeof(irOn4),
     irOn4},
     
    {REAR_SPEAKERS_ON,
     SZ_REAR_SPEAKERS_ON,
     &rearSpeakerState,
     0,
     NULL},
     
    {REAR_SPEAKERS_OFF,
     SZ_REAR_SPEAKERS_OFF,
     &rearSpeakerState,
     0,
     NULL},
     
    {FRONT_SPEAKERS_ON,
     SZ_FRONT_SPEAKERS_ON,
     &frontSpeakerState,
     0,
     NULL},
     
    {FRONT_SPEAKERS_OFF,
     SZ_FRONT_SPEAKERS_OFF,
     &frontSpeakerState,
     0,
     NULL},
     
    {EXIT,
     SZ_EXIT,
     &undefined,
     0,
     NULL}
};    

#endif  // ifndef COMMON_H
