var videoPower = {
   sz: "video power",
   state: "off"
}   
module.exports.videoPower = videoPower;
